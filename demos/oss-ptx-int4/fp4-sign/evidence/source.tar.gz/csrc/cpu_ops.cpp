#include "cpu_ops.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <mutex>
#include <thread>
#include <vector>

#ifdef HAS_OPENMP
#include <omp.h>
#define BNB_OMP_PARALLEL_FOR _Pragma("omp parallel for")
#else
#define BNB_OMP_PARALLEL_FOR
#endif

namespace {

constexpr int kCodebookSize = 256;

inline unsigned char lookup_code_index(const float* codebook, float value) {
    value = std::clamp(value, -1.0f, 1.0f);
    const float* begin = codebook;
    const float* end = codebook + kCodebookSize;
    const float* right = std::lower_bound(begin, end, value);
    if (right == begin) {
        return 0;
    }
    if (right == end) {
        return static_cast<unsigned char>(kCodebookSize - 1);
    }
    const float* left = right - 1;
    const float dist_left = std::fabs(value - *left);
    const float dist_right = std::fabs(*right - value);
    const unsigned char idx = static_cast<unsigned char>(right - begin);
    return dist_right < dist_left ? idx : idx - 1;
}

} // namespace

#if defined(_M_ARM64) || defined(__aarch64__)
#include <arm_neon.h>

// ARM NEON NF4 lookup table (16 float values indexed by 4-bit code)
static inline void neon_nf4_lut(float32x4_t lut[4]) {
    // Indices 0-15 map to NF4 dequantized values
    // Order: index 0 = -1.0, index 1 = -0.6962, ..., index 7 = 0.0, ..., index 15 = 1.0
    static const float nf4_values[16] = {
        -1.0f,
        -0.6961928009986877f,
        -0.5250730514526367f,
        -0.39491748809814453f,
        -0.28444138169288635f,
        -0.18477343022823334f,
        -0.09105003625154495f,
        0.0f,
        0.07958029955625534f,
        0.16093020141124725f,
        0.24611230194568634f,
        0.33791524171829224f,
        0.44070982933044434f,
        0.5626170039176941f,
        0.7229568362236023f,
        1.0f
    };
    lut[0] = vld1q_f32(nf4_values);
    lut[1] = vld1q_f32(nf4_values + 4);
    lut[2] = vld1q_f32(nf4_values + 8);
    lut[3] = vld1q_f32(nf4_values + 12);
}

// ARM NEON FP4 lookup table
static inline void neon_fp4_lut(float32x4_t lut[4]) {
    static const float fp4_values[16] = {
        0.0f, 5.208333333e-03f,  0.66666667f,  1.0f,  0.33333333f,  0.5f,  0.16666667f,  0.25f,
        0.0f, -5.208333333e-03f, -0.66666667f, -1.0f, -0.33333333f, -0.5f, -0.16666667f, -0.25f
    };
    lut[0] = vld1q_f32(fp4_values);
    lut[1] = vld1q_f32(fp4_values + 4);
    lut[2] = vld1q_f32(fp4_values + 8);
    lut[3] = vld1q_f32(fp4_values + 12);
}

// Efficient NEON float LUT lookup using indexed lane extraction
// The LUT has 16 float entries stored as a flat array for direct indexing
static inline float neon_lut_lookup_flat(const float* flat_lut, uint8_t idx) { return flat_lut[idx]; }

// Vectorized 4-bit dequantization: process 8 packed bytes = 16 output values
// Each byte contains two 4-bit values: high nibble first, low nibble second
static inline void
    neon_dequant_4bit_16values(const uint8_t* packed, float scale, const float32x4_t lut[4], float* out) {
    // Load 8 bytes = 16 x 4-bit values
    uint8x8_t raw = vld1_u8(packed);

    // Extract high and low nibbles
    uint8x8_t mask4 = vdup_n_u8(0x0F);
    uint8x8_t lo_nibbles = vand_u8(raw, mask4); // low nibble (second value)
    uint8x8_t hi_nibbles = vshr_n_u8(raw, 4);   // high nibble (first value)

    // Interleave hi/lo into 16-element index array for output ordering
    // output[2*i] = hi_nibble[i], output[2*i+1] = lo_nibble[i]
    uint8x8x2_t interleaved = vzip_u8(hi_nibbles, lo_nibbles);
    // interleaved.val[0] has elements 0-7, interleaved.val[1] has elements 8-15
    uint8x16_t indices = vcombine_u8(interleaved.val[0], interleaved.val[1]);

    // Reinterpret float LUT as 64-byte table for vqtbl4q_u8 lookup.
    // Each 4-bit index i maps to bytes [i*4 .. i*4+3] in the table.
    uint8x16x4_t lut_bytes = {
        vreinterpretq_u8_f32(lut[0]), vreinterpretq_u8_f32(lut[1]), vreinterpretq_u8_f32(lut[2]),
        vreinterpretq_u8_f32(lut[3])
    };
    // Multiply each index by 4 to get byte offset (max 15*4=60 < 64, safe)
    uint8x16_t base = vshlq_n_u8(indices, 2);
    // Expand each base offset to 4 consecutive bytes via zip
    const uint8x16_t off = vreinterpretq_u8_u32(vdupq_n_u32(0x03020100));
    uint8x8_t lo = vget_low_u8(base), hi = vget_high_u8(base);
    uint8x8x2_t z0 = vzip_u8(lo, lo);
    uint8x8x2_t z1 = vzip_u8(hi, hi);
    uint8x8x2_t zlo = vzip_u8(z0.val[0], z0.val[0]);
    uint8x8x2_t zhi = vzip_u8(z0.val[1], z0.val[1]);
    uint8x8x2_t zlo2 = vzip_u8(z1.val[0], z1.val[0]);
    uint8x8x2_t zhi2 = vzip_u8(z1.val[1], z1.val[1]);
    float32x4_t vscale = vdupq_n_f32(scale);
    float32x4_t v0 = vreinterpretq_f32_u8(vqtbl4q_u8(lut_bytes, vaddq_u8(vcombine_u8(zlo.val[0], zlo.val[1]), off)));
    float32x4_t v1 = vreinterpretq_f32_u8(vqtbl4q_u8(lut_bytes, vaddq_u8(vcombine_u8(zhi.val[0], zhi.val[1]), off)));
    float32x4_t v2 = vreinterpretq_f32_u8(vqtbl4q_u8(lut_bytes, vaddq_u8(vcombine_u8(zlo2.val[0], zlo2.val[1]), off)));
    float32x4_t v3 = vreinterpretq_f32_u8(vqtbl4q_u8(lut_bytes, vaddq_u8(vcombine_u8(zhi2.val[0], zhi2.val[1]), off)));

    vst1q_f32(out, vmulq_f32(v0, vscale));
    vst1q_f32(out + 4, vmulq_f32(v1, vscale));
    vst1q_f32(out + 8, vmulq_f32(v2, vscale));
    vst1q_f32(out + 12, vmulq_f32(v3, vscale));
}

// NEON-optimized BF16 to float conversion (4 values at a time)
static inline float32x4_t neon_bf16x4_to_f32(const bf16_t* src) {
    // BF16 is upper 16 bits of float32, so shift left by 16
    uint16x4_t raw = vld1_u16(reinterpret_cast<const uint16_t*>(src));
    uint32x4_t wide = vshll_n_u16(raw, 16);
    return vreinterpretq_f32_u32(wide);
}

// NEON-optimized float to BF16 conversion (4 values at a time, with rounding)
static inline void neon_f32_to_bf16x4(const float32x4_t src, bf16_t* dst) {
    uint32x4_t bits = vreinterpretq_u32_f32(src);
    // Round to nearest even: add 0x7FFF + ((bits >> 16) & 1)
    uint32x4_t lsb = vshrq_n_u32(bits, 16);
    lsb = vandq_u32(lsb, vdupq_n_u32(1));
    uint32x4_t rounding = vaddq_u32(vdupq_n_u32(0x7FFF), lsb);
    bits = vaddq_u32(bits, rounding);
    // Extract upper 16 bits
    uint16x4_t result = vshrn_n_u32(bits, 16);
    vst1_u16(reinterpret_cast<uint16_t*>(dst), result);
}

// NEON-optimized float to FP16 conversion (4 values at a time)
static inline void neon_f32_to_fp16x4(const float32x4_t src, fp16_t* dst) {
    // ARM64 has native FP16 conversion
    float16x4_t half = vcvt_f16_f32(src);
    vst1_u16(reinterpret_cast<uint16_t*>(dst), vreinterpret_u16_f16(half));
}

// NEON-optimized FP16 to float conversion (4 values at a time)
static inline float32x4_t neon_fp16x4_to_f32(const fp16_t* src) {
    uint16x4_t raw = vld1_u16(reinterpret_cast<const uint16_t*>(src));
    return vcvt_f32_f16(vreinterpret_f16_u16(raw));
}

// NEON-optimized absmax computation for a block of float32, bf16, or fp16.
template <typename T> static inline float neon_absmax(const T* data, long long n) {
    float32x4_t vmax = vdupq_n_f32(0.0f);
    long long i = 0;
    for (; i + 16 <= n; i += 16) {
        float32x4_t v0, v1, v2, v3;
        if constexpr (std::is_same<T, float>::value) {
            const float* p = reinterpret_cast<const float*>(data + i);
            v0 = vld1q_f32(p);
            v1 = vld1q_f32(p + 4);
            v2 = vld1q_f32(p + 8);
            v3 = vld1q_f32(p + 12);
        } else if constexpr (std::is_same<T, bf16_t>::value) {
            v0 = neon_bf16x4_to_f32(data + i);
            v1 = neon_bf16x4_to_f32(data + i + 4);
            v2 = neon_bf16x4_to_f32(data + i + 8);
            v3 = neon_bf16x4_to_f32(data + i + 12);
        } else {
            v0 = neon_fp16x4_to_f32(data + i);
            v1 = neon_fp16x4_to_f32(data + i + 4);
            v2 = neon_fp16x4_to_f32(data + i + 8);
            v3 = neon_fp16x4_to_f32(data + i + 12);
        }
        vmax = vmaxq_f32(
            vmax, vmaxq_f32(vmaxq_f32(vabsq_f32(v0), vabsq_f32(v1)), vmaxq_f32(vabsq_f32(v2), vabsq_f32(v3)))
        );
    }
    for (; i + 4 <= n; i += 4) {
        float32x4_t v;
        if constexpr (std::is_same<T, float>::value)
            v = vld1q_f32(reinterpret_cast<const float*>(data + i));
        else if constexpr (std::is_same<T, bf16_t>::value)
            v = neon_bf16x4_to_f32(data + i);
        else
            v = neon_fp16x4_to_f32(data + i);
        vmax = vmaxq_f32(vmax, vabsq_f32(v));
    }
    float result = vmaxvq_f32(vmax);
    for (; i < n; ++i) {
        float val;
        if constexpr (std::is_same<T, float>::value)
            val = data[i];
        else if constexpr (std::is_same<T, bf16_t>::value)
            val = bf16_to_float(data[i].v);
        else
            val = fp16_to_float(data[i].v);
        result = std::max(result, std::fabs(val));
    }
    return result;
}

// NEON-optimized norm_to_lut_index for 4 float values at a time
// Maps [-1, 1] → [0, 65535]
static inline uint16x4_t neon_norm_to_lut_index_x4(float32x4_t vals) {
    // clamp to [-1, 1]
    vals = vmaxq_f32(vals, vdupq_n_f32(-1.0f));
    vals = vminq_f32(vals, vdupq_n_f32(1.0f));
    // (val + 1.0) * 0.5 * 65535 + 0.5
    float32x4_t result = vmlaq_f32(vdupq_n_f32(0.5f), vaddq_f32(vals, vdupq_n_f32(1.0f)), vdupq_n_f32(0.5f * 65535.0f));
    uint32x4_t u32 = vcvtq_u32_f32(result);
    return vmovn_u32(u32);
}

#endif // _M_ARM64 || __aarch64__

#if defined(__AVX512F__)

inline __m256i cvt_fp32_to_fp16(const __m512 src) {
    return _mm512_cvtps_ph(src, (_MM_FROUND_TO_NEAREST_INT | _MM_FROUND_NO_EXC));
}

inline __m256i cvt_fp32_to_bf16(const __m512 src) {
#if defined(__AVX512BF16__)
    if (has_avx512bf16()) {
        return reinterpret_cast<__m256i>(_mm512_cvtneps_pbh(src));
    }
#endif
    __m512i value = _mm512_castps_si512(src);
    __m512i nan = _mm512_set1_epi32(0xffff);
    auto mask_value = _mm512_cmp_ps_mask(src, src, _CMP_ORD_Q);
    __m512i ones = _mm512_set1_epi32(0x1);
    __m512i vec_bias = _mm512_set1_epi32(0x7fff);
    // uint32_t lsb = (input >> 16) & 1;
    auto t_value = _mm512_and_si512(_mm512_srli_epi32(value, 16), ones);
    // uint32_t rounding_bias = 0x7fff + lsb;
    t_value = _mm512_add_epi32(t_value, vec_bias);
    // input += rounding_bias;
    t_value = _mm512_add_epi32(t_value, value);
    // input = input >> 16;
    t_value = _mm512_srli_epi32(t_value, 16);
    // Check NaN before converting back to bf16
    t_value = _mm512_mask_blend_epi32(mask_value, nan, t_value);
    return _mm512_cvtusepi32_epi16(t_value);
}

static inline __m512 set_nf4_lut() {
    return _mm512_set_ps(
        1.0f, 0.7229568362236023, 0.5626170039176941, 0.44070982933044434, 0.33791524171829224, 0.24611230194568634,
        0.16093020141124725, 0.07958029955625534, 0.0f, -0.09105003625154495, -0.18477343022823334,
        -0.28444138169288635, -0.39491748809814453, -0.5250730514526367, -0.6961928009986877, -1.0f
    );
}

static inline __m512 set_fp4_lut() {
    return _mm512_set_ps(
        -0.2500f, -0.16666667f, -0.5000f, -0.33333333f, -1.0000f, -0.66666667f, -5.208333333e-03f, 0.0000f, 0.2500f,
        0.16666667f, 0.5000f, 0.33333333f, 1.0000f, 0.66666667f, 5.208333333e-03f, 0.0000f
    );
}
#endif

static constexpr float fp4_lut[16] = {
    0.0f,  0.005208333333f,  0.66666667f,  1.0f,  0.33333333f,  0.5f,  0.16666667f,  0.25f,
    -0.0f, -0.005208333333f, -0.66666667f, -1.0f, -0.33333333f, -0.5f, -0.16666667f, -0.25f,
};
static constexpr float nf4_lut[16] = {
    -1.0f,
    -0.6961928009986877f,
    -0.5250730514526367f,
    -0.39491748809814453f,
    -0.28444138169288635f,
    -0.18477343022823334f,
    -0.09105003625154495f,
    0.0f,
    0.07958029955625534f,
    0.16093020141124725f,
    0.24611230194568634f,
    0.33791524171829224f,
    0.44070982933044434f,
    0.5626170039176941f,
    0.7229568362236023f,
    1.0f,
};

// 4-bit (FP4 / NF4) dequantization helper extracted from the original else branch.
// DATA_TYPE: 1 = FP4, 2 = NF4
template <typename T, int DATA_TYPE>
void dequantizeBlockwise4bitCpu(
    unsigned char* A, const float* absmax, T* out, long long blocksize, long long m, long long n
) {
    static_assert(DATA_TYPE == 1 || DATA_TYPE == 2, "dequantizeBlockwise4bitCpu called with non 4-bit DATA_TYPE");
    if (blocksize <= 0 || m < 0 || n <= 0)
        return;

#if defined(_M_ARM64) || defined(__aarch64__)
    // n % blocksize == 0: absmax is organized by flat element blocks; row and block
    // boundaries must align or the 2D absmax indexing gives wrong scale values.
    if (n % blocksize == 0) {
        long long dim_0 = m;
        long long dim_1 = n;
        long long input_dim_1 = dim_1 >> 1;
        long long absmax_dim_1 = dim_1 / blocksize;
        float32x4_t neon_lut[4];
        if constexpr (DATA_TYPE == 1) {
            neon_fp4_lut(neon_lut);
        } else {
            neon_nf4_lut(neon_lut);
        }
        constexpr long long k_step = 8; // 8 packed bytes = 16 output values
        BNB_OMP_PARALLEL_FOR
        for (long long block_idx = 0; block_idx < dim_0; ++block_idx) {
            for (long long k = 0; k < input_dim_1; k += k_step) {
                long long scale_idx = k * 2 / blocksize;
                float scale = absmax[block_idx * absmax_dim_1 + scale_idx];
                const uint8_t* p = &A[block_idx * input_dim_1 + k];
                float tmp_f32[16];
                neon_dequant_4bit_16values(p, scale, neon_lut, tmp_f32);
                T* pout = &out[block_idx * dim_1 + k * 2];
                if constexpr (std::is_same<T, float>()) {
                    std::memcpy(pout, tmp_f32, 16 * sizeof(float));
                } else if constexpr (std::is_same<T, bf16_t>()) {
                    neon_f32_to_bf16x4(vld1q_f32(tmp_f32), pout);
                    neon_f32_to_bf16x4(vld1q_f32(tmp_f32 + 4), pout + 4);
                    neon_f32_to_bf16x4(vld1q_f32(tmp_f32 + 8), pout + 8);
                    neon_f32_to_bf16x4(vld1q_f32(tmp_f32 + 12), pout + 12);
                } else {
                    neon_f32_to_fp16x4(vld1q_f32(tmp_f32), pout);
                    neon_f32_to_fp16x4(vld1q_f32(tmp_f32 + 4), pout + 4);
                    neon_f32_to_fp16x4(vld1q_f32(tmp_f32 + 8), pout + 8);
                    neon_f32_to_fp16x4(vld1q_f32(tmp_f32 + 12), pout + 12);
                }
            }
        }
        return;
    }
#endif // _M_ARM64 || __aarch64__

#if defined(__AVX512F__)
    if (has_avx512f()) {
        long long dim_0 = m;
        long long dim_1 = n;
        long long input_dim_1 = dim_1 >> 1;
        long long absmax_dim_1 = dim_1 / blocksize;
        using Tcomp = float;
        constexpr auto VEC_LEN = sizeof(__m512i) / sizeof(Tcomp); // 16
        if (dim_1 % VEC_LEN == 0 && blocksize >= VEC_LEN) {
            __m512 lut = DATA_TYPE == 1 ? set_fp4_lut() : set_nf4_lut();
            constexpr auto k_step = VEC_LEN / 2; // 8
            BNB_OMP_PARALLEL_FOR
            for (int block_idx = 0; block_idx < dim_0; ++block_idx) {
                for (int k = 0; k < input_dim_1; k += k_step) {
                    const uint8_t* p = &A[block_idx * input_dim_1 + k];
                    auto scale_idx = k * 2 / blocksize;
                    auto vscales = _mm512_set1_ps((float)absmax[block_idx * absmax_dim_1 + scale_idx]);
                    // Unpack 8 packed bytes into 16 nibble indices using SSE.
                    // Each byte holds two 4-bit values; high nibble is the first output element.
                    __m128i raw = _mm_loadl_epi64(reinterpret_cast<const __m128i*>(p));
                    __m128i mask4 = _mm_set1_epi8(0x0f);
                    __m128i hi = _mm_and_si128(_mm_srli_epi16(raw, 4), mask4);
                    __m128i lo = _mm_and_si128(raw, mask4);
                    __m128i packed_128 = _mm_unpacklo_epi8(hi, lo);
                    __m512i vint32 = _mm512_cvtepu8_epi32(packed_128);
                    // Table look-up
                    __m512 vout = _mm512_permutexvar_ps(vint32, lut);
                    // Apply scale
                    vout = _mm512_mul_ps(vout, vscales);
                    // Store results
                    T* pout = &out[block_idx * dim_1 + k * 2];
                    if constexpr (std::is_same<T, float>()) {
                        _mm512_storeu_ps(pout, vout);
                    } else if constexpr (std::is_same<T, bf16_t>()) {
                        _mm256_storeu_si256((__m256i*)pout, cvt_fp32_to_bf16(vout));
                    } else if constexpr (std::is_same<T, fp16_t>()) {
                        _mm256_storeu_si256((__m256i*)pout, cvt_fp32_to_fp16(vout));
                    }
                }
            }
            return;
        }
    }
#endif
    // Scalar fallback branch
    const float* lut = DATA_TYPE == 1 ? fp4_lut : nf4_lut;
    long long total = m * n;
    BNB_OMP_PARALLEL_FOR
    for (long long block_idx = 0; block_idx < total; block_idx += blocksize) {
        long long valid_items = (total - block_idx >= blocksize ? blocksize : total - block_idx);
        float scale = absmax[block_idx / blocksize];
        for (long long i = 0; i < valid_items; i += 2) {
            long long byte_index = (block_idx + i) >> 1;
            unsigned char byte = A[byte_index];

            // High nibble first (matches previous code logic)
            float v0 = lut[byte >> 4] * scale;
            // Low nibble second
            float v1 = lut[byte & 0x0F] * scale;

            if constexpr (std::is_same<T, bf16_t>::value) {
                out[block_idx + i] = float_to_bf16(v0);
            } else if constexpr (std::is_same<T, fp16_t>::value) {
                out[block_idx + i] = float_to_fp16(v0);
            } else {
                out[block_idx + i] = static_cast<T>(v0);
            }

            if (i + 1 < valid_items) {
                if constexpr (std::is_same<T, bf16_t>::value) {
                    out[block_idx + i + 1] = float_to_bf16(v1);
                } else if constexpr (std::is_same<T, fp16_t>::value) {
                    out[block_idx + i + 1] = float_to_fp16(v1);
                } else {
                    out[block_idx + i + 1] = static_cast<T>(v1);
                }
            }
        }
    }
}

template <typename T>
void dequantizeBlockwise8bitCpu(
    float* code, unsigned char* A, const float* absmax, T* out, long long blocksize, long long n
) {
    if (blocksize <= 0 || n <= 0)
        return;
    // 8-bit path
    BNB_OMP_PARALLEL_FOR
    for (long long block_idx = 0; block_idx < n; block_idx += blocksize) {
        long long valid_items = (n - block_idx >= blocksize ? blocksize : n - block_idx);
        long long block_end = block_idx + valid_items;
        float scale = absmax[block_idx / blocksize];
#if defined(_M_ARM64) || defined(__aarch64__)
        {
            float32x4_t vscale = vdupq_n_f32(scale);
            long long i = block_idx;
            for (; i + 4 <= block_end; i += 4) {
                float tmp[4] = {code[A[i]], code[A[i + 1]], code[A[i + 2]], code[A[i + 3]]};
                float32x4_t v = vmulq_f32(vld1q_f32(tmp), vscale);
                if constexpr (std::is_same<T, float>::value)
                    vst1q_f32(reinterpret_cast<float*>(out + i), v);
                else if constexpr (std::is_same<T, bf16_t>::value)
                    neon_f32_to_bf16x4(v, out + i);
                else
                    neon_f32_to_fp16x4(v, out + i);
            }
            for (; i < block_end; ++i) {
                float v = code[A[i]] * scale;
                if constexpr (std::is_same<T, bf16_t>::value)
                    out[i] = float_to_bf16(v);
                else if constexpr (std::is_same<T, fp16_t>::value)
                    out[i] = float_to_fp16(v);
                else
                    out[i] = static_cast<T>(v);
            }
        }
#else
#pragma omp simd
        for (long long i = block_idx; i < block_end; ++i) {
            float v = code[A[i]] * scale;
            if constexpr (std::is_same<T, bf16_t>::value) {
                out[i] = float_to_bf16(v);
            } else if constexpr (std::is_same<T, fp16_t>::value) {
                out[i] = float_to_fp16(v);
            } else {
                out[i] = static_cast<T>(v);
            }
        }
#endif
    }
}

// Prevent GCC/Clang from emitting EVEX-encoded AVX512 instructions in plain scalar code.
// The global -mavx512vl flag can cause GCC to fold broadcasts into EVEX encoding (e.g. vmulps {1to4})
// which would SIGILL on non-AVX512 CPUs like Zen3. These functions are scalar C++ and don't need AVX512.
#if defined(__GNUC__) && (defined(__x86_64__) || defined(__i386__))
#pragma GCC push_options
#pragma GCC target("avx2,fma,no-avx512f")
#endif

// Precomputed direct lookup table: maps quantized uint16 index [0..65535] to codebook index.
// Replaces binary search per element with a single array access.
static constexpr int kLUTSize = 65536;
static constexpr int kLUTCacheSlots = 4;

static void build_quantize_lut(const float* codebook, unsigned char* lut) {
    // codebook has 256 sorted entries in [-1, 1].
    // We discretize the [-1, 1] range into 65536 bins and find the nearest codebook entry for each.
    // Precompute midpoints between consecutive codebook entries for nearest-neighbor lookup.
    float midpoints[kCodebookSize - 1];
    for (int i = 0; i < kCodebookSize - 1; ++i) {
        midpoints[i] = 0.5f * (codebook[i] + codebook[i + 1]);
    }

    int code_idx = 0;
    for (int i = 0; i < kLUTSize; ++i) {
        // Map LUT index to normalized value in [-1, 1]
        float val = -1.0f + (2.0f * i) / (kLUTSize - 1);
        // Advance code_idx while the next midpoint is still below val
        while (code_idx < kCodebookSize - 1 && midpoints[code_idx] < val) {
            ++code_idx;
        }
        lut[i] = static_cast<unsigned char>(code_idx);
    }
}

// Per-thread LUT cache with multiple slots to avoid rebuilding when alternating codebooks
struct LUTCache {
    unsigned char luts[kLUTCacheSlots][kLUTSize];
    const float* cached_codes[kLUTCacheSlots] = {};
    // Store fingerprint to detect pointer reuse (ABA problem):
    // when a tensor is freed and a new one reuses the same address,
    // the pointer matches but the codebook content may differ.
    float cached_fingerprints[kLUTCacheSlots][4] = {};
    int next_slot = 0;

    static void compute_fingerprint(const float* code, float* fp) {
        fp[0] = code[0];
        fp[1] = code[1];
        fp[2] = code[127];
        fp[3] = code[255];
    }

    const unsigned char* get_lut(const float* code) {
        float fp[4];
        compute_fingerprint(code, fp);
        for (int i = 0; i < kLUTCacheSlots; ++i) {
            if (cached_codes[i] == code && cached_fingerprints[i][0] == fp[0] && cached_fingerprints[i][1] == fp[1] &&
                cached_fingerprints[i][2] == fp[2] && cached_fingerprints[i][3] == fp[3]) {
                return luts[i];
            }
        }
        // Cache miss: build and store in next slot (round-robin)
        int slot = next_slot;
        next_slot = (next_slot + 1) % kLUTCacheSlots;
        build_quantize_lut(code, luts[slot]);
        cached_codes[slot] = code;
        for (int j = 0; j < 4; ++j)
            cached_fingerprints[slot][j] = fp[j];
        return luts[slot];
    }
};

// Single global LUT cache (protected by mutex for thread safety during build)
static LUTCache g_lut_cache;
static std::mutex g_lut_mutex;

static const unsigned char* get_global_lut(const float* code) {
    std::lock_guard<std::mutex> lock(g_lut_mutex);
    return g_lut_cache.get_lut(code);
}

// Convert a normalized value in [-1, 1] to LUT index [0, 65535]
static inline uint16_t norm_to_lut_index(float val) {
    val = std::clamp(val, -1.0f, 1.0f);
    return static_cast<uint16_t>((val + 1.0f) * 0.5f * (kLUTSize - 1) + 0.5f);
}

template <typename T>
void quantize_cpu_impl(float* code, const T* A, float* absmax, unsigned char* out, long long blocksize, long long n) {
    if (blocksize <= 0 || n <= 0)
        return;

    // Get LUT from global cache (built once per codebook, shared by all OMP threads)
    const unsigned char* lut = get_global_lut(code);

    const long long num_blocks = (n + blocksize - 1) / blocksize;

    BNB_OMP_PARALLEL_FOR
    for (long long b = 0; b < num_blocks; ++b) {
        const long long block_start = b * blocksize;
        const long long block_end = std::min(block_start + blocksize, n);
        const long long block_len = block_end - block_start;

        // Compute absmax for this block
        float absmax_block = 0.0f;

#if defined(_M_ARM64) || defined(__aarch64__)
        absmax_block = neon_absmax<T>(A + block_start, block_len);
#else
#pragma omp simd reduction(max : absmax_block)
        for (long long i = block_start; i < block_end; ++i) {
            float val;
            if constexpr (std::is_same<T, float>::value)
                val = A[i];
            else if constexpr (std::is_same<T, bf16_t>::value)
                val = bf16_to_float(A[i].v);
            else
                val = fp16_to_float(A[i].v);
            absmax_block = std::max(absmax_block, std::fabs(val));
        }
#endif

        absmax[b] = absmax_block;

        if (absmax_block == 0.0f) {
            for (long long i = block_start; i < block_end; ++i) {
                out[i] = 0;
            }
            continue;
        }

        const float inv_absmax = 1.0f / absmax_block;

#if defined(_M_ARM64) || defined(__aarch64__)
        {
            long long i = 0;
            float32x4_t vinv = vdupq_n_f32(inv_absmax);
            for (; i + 4 <= block_len; i += 4) {
                float32x4_t v;
                if constexpr (std::is_same<T, float>::value)
                    v = vld1q_f32(reinterpret_cast<const float*>(A + block_start + i));
                else if constexpr (std::is_same<T, bf16_t>::value)
                    v = neon_bf16x4_to_f32(A + block_start + i);
                else
                    v = neon_fp16x4_to_f32(A + block_start + i);
                v = vmulq_f32(v, vinv);
                uint16x4_t indices = neon_norm_to_lut_index_x4(v);
                uint16_t idx_arr[4];
                vst1_u16(idx_arr, indices);
                out[block_start + i] = lut[idx_arr[0]];
                out[block_start + i + 1] = lut[idx_arr[1]];
                out[block_start + i + 2] = lut[idx_arr[2]];
                out[block_start + i + 3] = lut[idx_arr[3]];
            }
            for (; i < block_len; ++i) {
                float val;
                if constexpr (std::is_same<T, float>::value)
                    val = A[block_start + i];
                else if constexpr (std::is_same<T, bf16_t>::value)
                    val = bf16_to_float(A[block_start + i].v);
                else
                    val = fp16_to_float(A[block_start + i].v);
                out[block_start + i] = lut[norm_to_lut_index(val * inv_absmax)];
            }
        }
#else
        for (long long i = block_start; i < block_end; ++i) {
            float val;
            if constexpr (std::is_same<T, float>::value)
                val = A[i];
            else if constexpr (std::is_same<T, bf16_t>::value)
                val = bf16_to_float(A[i].v);
            else
                val = fp16_to_float(A[i].v);
            out[i] = lut[norm_to_lut_index(val * inv_absmax)];
        }
#endif
    }
}

void quantize_cpu(float* code, float* A, float* absmax, unsigned char* out, long long blocksize, long long n) {
    quantize_cpu_impl<float>(code, A, absmax, out, blocksize, n);
}

void quantize_cpu_bf16(float* code, bf16_t* A, float* absmax, unsigned char* out, long long blocksize, long long n) {
    quantize_cpu_impl<bf16_t>(code, A, absmax, out, blocksize, n);
}

void quantize_cpu_fp16(float* code, fp16_t* A, float* absmax, unsigned char* out, long long blocksize, long long n) {
    quantize_cpu_impl<fp16_t>(code, A, absmax, out, blocksize, n);
}

#if defined(__GNUC__) && (defined(__x86_64__) || defined(__i386__))
#pragma GCC pop_options
#endif

#if defined(__AVX512F__) && defined(__AVX512BF16__)

#define CVT_BF16_TO_FP32(a) _mm512_castsi512_ps(_mm512_slli_epi32(_mm512_cvtepu16_epi32(a), 16))

template <typename scalar_t, int BLOCK_M, int BLOCK_N, int DATA_TYPE> struct tinygemm_kernel_nn {
    static inline void apply(
        const scalar_t*, const unsigned char*, scalar_t*, const scalar_t*, int64_t, int, int64_t, int64_t, int64_t,
        int64_t, int64_t
    ) {
        static_assert(sizeof(scalar_t) == 0, "tinygemm_kernel_nn primary template should never be instantiated");
    }
};

template <int BLOCK_M, int BLOCK_N, int DATA_TYPE> struct tinygemm_kernel_nn<bf16_t, BLOCK_M, BLOCK_N, DATA_TYPE> {
    static inline void apply(
        const bf16_t* __restrict__ A, const unsigned char* __restrict__ B, bf16_t* __restrict__ C,
        const bf16_t* __restrict__ Bs, int64_t K, int group_size, int64_t lda, int64_t ldb, int64_t ldc,
        int64_t strideBz, int64_t strideBs
    ) {
        static_assert(BLOCK_N % 32 == 0);
        constexpr int ROWS = BLOCK_M;      // 32
        constexpr int COLS = BLOCK_N / 16; // 2

        // prefetch distance
        constexpr int PREFETCH_SIZE_K = 16 * 4;

        __m512bh va;
        __m512bh vb[COLS];
        __m512 vc[ROWS * COLS];
        __m512 vc_master[ROWS * COLS];

        __m256i mask = _mm256_set1_epi8(0xF); // lower 4 bit
        __m256i fifteen = _mm256_set1_epi8(15);
        __m512i lut = DATA_TYPE == 1
                          ? _mm512_set_epi16(
                                0x0000, -0x4180, -0x41D5, -0x4100, -0x4155, -0x4080, -0x40D5, -0x4455, 0x0000, 0x3E80,
                                0x3E2B, 0x3F00, 0x3EAB, 0x3F80, 0x3F2B, 0x3BAB, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000,
                                0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000
                            )
                          : _mm512_set_epi16(
                                0x0000, 0x3F80, 0x3F39, 0x3F10, 0x3EE2, 0x3EAD, 0x3E7C, 0x3E25, 0x3DA3, 0x0000, -0x4246,
                                -0x41C3, -0x416E, -0x4136, -0x40FA, -0x40CE, -0x4080, 0x0000, 0x0000, 0x0000, 0x0000,
                                0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000
                            );
        __m512 scales[COLS];
        const int64_t K2 = K >> 1;
        const int64_t lda2 = lda >> 1;
        const int64_t ldb2 = ldb;            // ldb * 2 >> 1;
        const int64_t gs2 = group_size >> 1; // 64 / 2 = 32
        const float* a_ptr = reinterpret_cast<const float*>(A);

        auto loadc = [&](auto i) {
            constexpr int col = i % COLS;
            vc_master[i] = _mm512_set1_ps(0.f);
        };
        Unroll<ROWS * COLS>{}(loadc);

        auto pre_compute = [&](auto i, int64_t kgs) {
            constexpr int row = i / COLS;
            constexpr int col = i % COLS;
            vc[i] = _mm512_set1_ps(0.f); // reset accumulator

            // load scales
            if constexpr (row == 0 && col % 2 == 0) {
                // Bs layout: [K/gs, BLOCK_N] : [strideBs, 1], dtype=bf16
                __m512i tmp = _mm512_loadu_si512(reinterpret_cast<const __m512i*>(Bs + kgs * strideBs + col * 16));
                scales[col] = CVT_BF16_TO_FP32(_mm512_extracti32x8_epi32(tmp, 0));
                scales[col + 1] = CVT_BF16_TO_FP32(_mm512_extracti32x8_epi32(tmp, 1));
            }
        };
        auto compute = [&](auto i, int64_t k) {
            constexpr int row = i / COLS;
            constexpr int col = i % COLS;

            if constexpr (col == 0) {
                va = (__m512bh)(_mm512_set1_ps(a_ptr[row * lda2 + k]));
            }
            if constexpr (row == 0 && col % 2 == 0) {
                __m256i vb_u4 = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(B + k * ldb + col * 16));

                // deinterleave and lookup to BF16
                __m256i vb_i8_lo = vb_u4 & mask;
                __m256i vb_i8_hi = _mm256_srli_epi16(vb_u4, 4) & mask;
                vb_i8_lo = _mm256_add_epi8(vb_i8_lo, fifteen);
                vb_i8_hi = _mm256_add_epi8(vb_i8_hi, fifteen);
                vb[col] = (__m512bh)_mm512_permutexvar_epi16(_mm512_cvtepi8_epi16(vb_i8_lo), lut);
                vb[col + 1] = (__m512bh)_mm512_permutexvar_epi16(_mm512_cvtepi8_epi16(vb_i8_hi), lut);

                if constexpr (PREFETCH_SIZE_K > 0) {
                    _mm_prefetch(B + (k + PREFETCH_SIZE_K) * ldb2 + col * 16, _MM_HINT_T0);
                }
            }
            vc[i] = _mm512_dpbf16_ps(vc[i], va, vb[col]);
        };
        auto post_compute = [&](auto i, int64_t kgs) {
            vc_master[i] = _mm512_fmadd_ps(vc[i], scales[i % COLS], vc_master[i]);
        };
        for (int64_t k = 0; k < K2; k += gs2) {
            Unroll<ROWS * COLS>{}(pre_compute, k / gs2);
            for (int64_t k_offset = 0; k_offset < gs2; ++k_offset) {
                Unroll<ROWS * COLS>{}(compute, k + k_offset);
            }
            Unroll<ROWS * COLS>{}(post_compute, k / gs2);
        }

        auto storec = [&](auto i) {
            constexpr int row = i / COLS;
            constexpr int col = i % COLS;
            if constexpr (col % 2 == 0) {
                _mm512_storeu_si512(
                    reinterpret_cast<__m512i*>(C + row * ldc + col * 16),
                    (__m512i)(_mm512_cvtne2ps_pbh(vc_master[i + 1], vc_master[i]))
                );
            }
        };
        Unroll<ROWS * COLS>{}(storec);
    }
};

#define LAUNCH_TINYGEMM_KERNEL_NN(MB_SIZE, NB_SIZE, DATA_TYPE)                                                         \
    tinygemm_kernel_nn<scalar_t, MB_SIZE, NB_SIZE, DATA_TYPE>::apply(                                                  \
        A + mb_start * lda, B + nb_start, C + mb_start * ldc + nb_start, Bs + nb_start, K, group_size, lda, ldb, ldc,  \
        strideBz, strideBs                                                                                             \
    );

template <typename scalar_t, int DATA_TYPE>
void tinygemm_kernel(
    const scalar_t* __restrict__ A, const unsigned char* __restrict__ B, scalar_t* __restrict__ C,
    const scalar_t* __restrict__ Bs, scalar_t* __restrict__ Btmp, float* __restrict__ Ctmp, int64_t M, int64_t N,
    int64_t K, int group_size, int64_t lda, int64_t ldb, int64_t ldc, int64_t strideBz, int64_t strideBs
) {
    constexpr int64_t BLOCK_M = 4;
    constexpr int64_t BLOCK_N = 64;
    const int64_t MB = div_up(M, BLOCK_M);
    const int64_t NB = div_up(N, BLOCK_N);
    for (int mb = 0; mb < MB; ++mb) {
        int64_t mb_start = mb * BLOCK_M;
        int64_t mb_size = std::min(BLOCK_M, M - mb_start);
        for (int64_t nb = 0; nb < NB; ++nb) {
            int64_t nb_start = nb * BLOCK_N;
            int64_t nb_size = std::min(BLOCK_N, N - nb_start);

            switch (mb_size << 4 | nb_size >> 4) {
            // mb_size = 1
            case 0x12:
                LAUNCH_TINYGEMM_KERNEL_NN(1, 32, DATA_TYPE);
                break;
            case 0x14:
                LAUNCH_TINYGEMM_KERNEL_NN(1, 64, DATA_TYPE);
                break;
            // mb_size = 2
            case 0x22:
                LAUNCH_TINYGEMM_KERNEL_NN(2, 32, DATA_TYPE);
                break;
            case 0x24:
                LAUNCH_TINYGEMM_KERNEL_NN(2, 64, DATA_TYPE);
                break;
            // mb_size = 3
            case 0x32:
                LAUNCH_TINYGEMM_KERNEL_NN(3, 32, DATA_TYPE);
                break;
            case 0x34:
                LAUNCH_TINYGEMM_KERNEL_NN(3, 64, DATA_TYPE);
                break;
            // mb_size = 4
            case 0x42:
                LAUNCH_TINYGEMM_KERNEL_NN(4, 32, DATA_TYPE);
                break;
            case 0x44:
                LAUNCH_TINYGEMM_KERNEL_NN(4, 64, DATA_TYPE);
                break;
            default: {
                std::fprintf(
                    stderr, "[bitsandbytes] Unexpected block size %lldx%lld\n", (long long)mb_size, (long long)nb_size
                );
                std::abort(); // or return; if you prefer silent exit
            }
            }
        }
    }
}

template <typename T, int DATA_TYPE>
void gemv_4bit_inference(
    int64_t M, int64_t N, int64_t K, const T* __restrict__ x, const unsigned char* __restrict__ w,
    const T* __restrict__ absmax, T* __restrict__ out, int64_t blocksize, int64_t x_stride, int64_t out_stride
) {
    constexpr int64_t BLOCK_M = block_size_m(); // 32
    constexpr int64_t BLOCK_N = block_size_n(); // 32
    const int64_t MB = div_up(M, BLOCK_M);      // （x + y -1）/ y, res = 1 when M <= 32
    const int64_t NB = div_up(N, BLOCK_N);
    // TODO: enable brgemm in the future.
    // const bool use_brgemm = M > 4;
    // const bool use_brgemm_dequant_out = M > 512;
    // T* Btmp_start = nullptr;
    // l2 cache block for n
    int64_t cache_blocks_nb = get_cache_blocks<T>(BLOCK_N * K);
    parallel_2d(MB, NB, [&](int64_t begin_mb, int64_t end_mb, int64_t begin_nb, int64_t end_nb) {
        // for brgemm, use float32 for accumulate
        alignas(64) float Ctmp[BLOCK_M * BLOCK_N];
        alignas(64) T Btmp_inner[BLOCK_N * BLOCK_K]; // BLOCK_K = 128
        for (int64_t nbb = begin_nb; nbb < end_nb; nbb += cache_blocks_nb) {
            for (int64_t mb = begin_mb; mb < end_mb; ++mb) { // 0-1
                for (int64_t nb = nbb; nb < std::min(nbb + cache_blocks_nb, end_nb); ++nb) {
                    int64_t mb_start = mb * BLOCK_M; // 0
                    int64_t mb_size = std::min(M - mb_start, BLOCK_M);
                    int64_t nb_start = nb * BLOCK_N;
                    int64_t nb_size = std::min(N - nb_start, BLOCK_N);
                    tinygemm_kernel<T, DATA_TYPE>(
                        /*   A  */ x + mb_start * x_stride,
                        /*   B  */ w + nb_start * K / 2, // divide by 2 since w is u4 packed in u8, K is w.size(1) * 2
                        /*   C  */ out + mb_start * out_stride + nb_start,
                        /*  Bs  */ absmax + nb_start,
                        /* Btmp */ Btmp_inner,
                        /* Ctmp */ Ctmp,
                        /*   M  */ mb_size,
                        /*   N  */ nb_size,
                        /*   K  */ K,
                        /*  gs  */ blocksize, // group_size
                        /* lda  */ x_stride,
                        /* ldb  */ nb_size,
                        /* ldc  */ out_stride,
                        /* sBz  */ N,
                        /* sBs  */ N
                    );
                }
            }
        }
        // if (use_brgemm) {
        //     at::native::cpublas::brgemm_release();
        // }
    });
}
#endif

//==============================================================
//                   TEMPLATE DEFINITIONS
//==============================================================

template void dequantizeBlockwise8bitCpu<float>(
    float* code, unsigned char* A, const float* absmax, float* out, long long blocksize, long long n
);
template void dequantizeBlockwise8bitCpu<fp16_t>(
    float* code, unsigned char* A, const float* absmax, fp16_t* out, long long blocksize, long long n
);
template void dequantizeBlockwise8bitCpu<bf16_t>(
    float* code, unsigned char* A, const float* absmax, bf16_t* out, long long blocksize, long long n
);

template void dequantizeBlockwise4bitCpu<float, FP4>(
    unsigned char* A, const float* absmax, float* out, long long blocksize, long long m, long long n
);
template void dequantizeBlockwise4bitCpu<float, NF4>(
    unsigned char* A, const float* absmax, float* out, long long blocksize, long long m, long long n
);

template void dequantizeBlockwise4bitCpu<fp16_t, FP4>(
    unsigned char* A, const float* absmax, fp16_t* out, long long blocksize, long long m, long long n
);
template void dequantizeBlockwise4bitCpu<fp16_t, NF4>(
    unsigned char* A, const float* absmax, fp16_t* out, long long blocksize, long long m, long long n
);

template void dequantizeBlockwise4bitCpu<bf16_t, FP4>(
    unsigned char* A, const float* absmax, bf16_t* out, long long blocksize, long long m, long long n
);
template void dequantizeBlockwise4bitCpu<bf16_t, NF4>(
    unsigned char* A, const float* absmax, bf16_t* out, long long blocksize, long long m, long long n
);

#if defined(__AVX512F__) && defined(__AVX512BF16__)
template void gemv_4bit_inference<bf16_t, FP4>(
    int64_t M, int64_t N, int64_t K, const bf16_t* __restrict__ x, const unsigned char* __restrict__ w,
    const bf16_t* __restrict__ absmax, bf16_t* __restrict__ out, int64_t blocksize, int64_t x_stride, int64_t out_stride
);
template void gemv_4bit_inference<bf16_t, NF4>(
    int64_t M, int64_t N, int64_t K, const bf16_t* __restrict__ x, const unsigned char* __restrict__ w,
    const bf16_t* __restrict__ absmax, bf16_t* __restrict__ out, int64_t blocksize, int64_t x_stride, int64_t out_stride
);
#endif
