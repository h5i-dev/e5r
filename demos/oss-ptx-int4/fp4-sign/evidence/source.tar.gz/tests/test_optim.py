import io
import sys
import time

from lion_pytorch import Lion
import pytest
import torch

import bitsandbytes as bnb
import bitsandbytes.functional as F
from bitsandbytes.utils import sync_gpu
from tests.helpers import describe_dtype, get_available_devices, id_formatter

# import apex

k = 20


def assert_most_approx_close(a, b, rtol=1e-3, atol=1e-3, max_error_count=0):
    idx = torch.isclose(a, b, rtol=rtol, atol=atol)
    error_count = (idx == 0).sum().item()
    if error_count > max_error_count:
        print(f"Too many values not close: assert {error_count} < {max_error_count}")
        torch.testing.assert_close(a, b, rtol=rtol, atol=atol)


str2optimizers = {}

## TODO: maybe remove these three.
str2optimizers["adam_pytorch"] = (None, torch.optim.Adam, bnb.optim.Adam)
str2optimizers["lion_pytorch"] = (None, Lion, bnb.optim.Lion)
str2optimizers["momentum_pytorch"] = (
    None,
    lambda pxx: torch.optim.SGD(pxx, 0.01, 0.9),
    bnb.optim.Adam,
)

str2optimizers["adam"] = (torch.optim.Adam, bnb.optim.Adam)
str2optimizers["adam8bit_blockwise"] = (torch.optim.Adam, lambda pxx: bnb.optim.Adam8bit(pxx))
str2optimizers["paged_adam"] = (torch.optim.Adam, bnb.optim.PagedAdam)
str2optimizers["paged_adamw"] = (torch.optim.AdamW, bnb.optim.PagedAdamW)
str2optimizers["paged_adam8bit_blockwise"] = (
    torch.optim.Adam,
    lambda pxx: bnb.optim.PagedAdam8bit(pxx),
)
str2optimizers["paged_adamw8bit_blockwise"] = (
    torch.optim.AdamW,
    lambda pxx: bnb.optim.PagedAdamW8bit(pxx),
)

str2optimizers["ademamix"] = (bnb.optim.ademamix._ReferenceAdEMAMix, bnb.optim.AdEMAMix)
str2optimizers["ademamix8bit_blockwise"] = (
    bnb.optim.ademamix._ReferenceAdEMAMix,
    lambda pxx: bnb.optim.AdEMAMix8bit(pxx),
)
str2optimizers["paged_ademamix"] = (bnb.optim.ademamix._ReferenceAdEMAMix, bnb.optim.PagedAdEMAMix)
str2optimizers["paged_ademamix8bit_blockwise"] = (
    bnb.optim.ademamix._ReferenceAdEMAMix,
    lambda pxx: bnb.optim.PagedAdEMAMix8bit(pxx),
)
str2optimizers["ademamix_scheduled"] = (
    lambda pxx: bnb.optim.ademamix._ReferenceAdEMAMix(pxx, t_alpha=k, t_beta3=k),
    lambda pxx: bnb.optim.AdEMAMix(pxx, t_alpha=k, t_beta3=k),
)
str2optimizers["paged_ademamix_scheduled"] = (
    lambda pxx: bnb.optim.ademamix._ReferenceAdEMAMix(pxx, t_alpha=k, t_beta3=k),
    lambda pxx: bnb.optim.PagedAdEMAMix(pxx, t_alpha=k, t_beta3=k),
)
str2optimizers["ademamix8bit_blockwise_scheduled"] = (
    lambda pxx: bnb.optim.ademamix._ReferenceAdEMAMix(pxx, t_alpha=100, t_beta3=100),
    lambda pxx: bnb.optim.AdEMAMix8bit(pxx, t_alpha=100, t_beta3=100),
)
str2optimizers["paged_ademamix8bit_blockwise_scheduled"] = (
    lambda pxx: bnb.optim.ademamix._ReferenceAdEMAMix(pxx, t_alpha=100, t_beta3=100),
    lambda pxx: bnb.optim.PagedAdEMAMix8bit(pxx, t_alpha=100, t_beta3=100),
)

str2optimizers["lion"] = (Lion, bnb.optim.Lion)
str2optimizers["paged_lion"] = (Lion, bnb.optim.PagedLion)
str2optimizers["lion8bit_blockwise"] = (Lion, lambda pxx: bnb.optim.Lion8bit(pxx))
str2optimizers["paged_lion8bit_blockwise"] = (Lion, lambda pxx: bnb.optim.PagedLion8bit(pxx))

str2optimizers["momentum"] = (
    lambda pxx: torch.optim.SGD(pxx, 0.01, 0.9),
    lambda pxx: bnb.optim.SGD(pxx, 0.01, 0.9),
)
str2optimizers["momentum8bit_blockwise"] = (
    lambda pxx: torch.optim.SGD(pxx, 0.01, 0.9),
    lambda pxx: bnb.optim.SGD8bit(pxx, 0.01, 0.9),
)

str2optimizers["lars"] = (
    lambda pxx: bnb.optim.PytorchLARS(pxx, 0.01, 0.9),
    lambda pxx: bnb.optim.LARS(pxx, 0.01, 0.9),
)

str2optimizers["rmsprop"] = (
    lambda pxx: torch.optim.RMSprop(pxx, 0.01, 0.9),
    lambda pxx: bnb.optim.RMSprop(pxx, 0.01, 0.9),
)
str2optimizers["rmsprop8bit_blockwise"] = (
    lambda pxx: torch.optim.RMSprop(pxx, 0.01, 0.9),
    lambda pxx: bnb.optim.RMSprop8bit(pxx, 0.01, 0.9),
)

str2statenames = {}
str2statenames["adam"] = [("exp_avg", "state1"), ("exp_avg_sq", "state2")]
str2statenames["paged_adamw"] = [("exp_avg", "state1"), ("exp_avg_sq", "state2")]
str2statenames["paged_adam"] = [("exp_avg", "state1"), ("exp_avg_sq", "state2")]
str2statenames["lion"] = [("exp_avg", "state1")]
str2statenames["paged_lion"] = [("exp_avg", "state1")]
str2statenames["momentum"] = [("momentum_buffer", "state1")]
str2statenames["lars"] = [("momentum_buffer", "state1")]
str2statenames["lamb"] = [("exp_avg", "state1"), ("exp_avg_sq", "state2")]
str2statenames["rmsprop"] = [("square_avg", "state1")]

str2statenames["adam8bit_blockwise"] = [
    ("exp_avg", "state1", "qmap1", "absmax1"),
    ("exp_avg_sq", "state2", "qmap2", "absmax2"),
]
str2statenames["paged_adam8bit_blockwise"] = [
    ("exp_avg", "state1", "qmap1", "absmax1"),
    ("exp_avg_sq", "state2", "qmap2", "absmax2"),
]
str2statenames["paged_adamw8bit_blockwise"] = [
    ("exp_avg", "state1", "qmap1", "absmax1"),
    ("exp_avg_sq", "state2", "qmap2", "absmax2"),
]

str2statenames["momentum8bit_blockwise"] = [("momentum_buffer", "state1", "qmap1", "absmax1")]
str2statenames["rmsprop8bit_blockwise"] = [("square_avg", "state1", "qmap1", "absmax1")]
str2statenames["lion8bit_blockwise"] = [("exp_avg", "state1", "qmap1", "absmax1")]
str2statenames["paged_lion8bit_blockwise"] = [("exp_avg", "state1", "qmap1", "absmax1")]

str2statenames["ademamix"] = str2statenames["ademamix_scheduled"] = [("m1_m2", "state1"), ("nu", "state2")]
str2statenames["paged_ademamix"] = str2statenames["paged_ademamix_scheduled"] = [("m1_m2", "state1"), ("nu", "state2")]
str2statenames["ademamix8bit_blockwise"] = str2statenames["ademamix8bit_blockwise_scheduled"] = [
    ("m1_m2", "state1", "qmap1", "absmax1"),
    ("nu", "state2", "qmap2", "absmax2"),
]
str2statenames["paged_ademamix8bit_blockwise"] = [
    ("m1_m2", "state1", "qmap1", "absmax1"),
    ("nu", "state2", "qmap2", "absmax2"),
]

optimizer_names_32bit = [
    "adam",
    "paged_adamw",
    "paged_adam",
    "momentum",
    "lars",
    "rmsprop",
    "lion",
    "paged_lion",
    "ademamix",
    "ademamix_scheduled",
    "paged_ademamix",
    "paged_ademamix_scheduled",
]


@pytest.mark.parametrize("optim_name", optimizer_names_32bit, ids=id_formatter("opt"))
@pytest.mark.parametrize("gtype", [torch.float32, torch.float16, torch.bfloat16], ids=describe_dtype)
@pytest.mark.parametrize("dim1", [1024], ids=id_formatter("dim1"))
@pytest.mark.parametrize("dim2", [32, 1024, 4097, 1], ids=id_formatter("dim2"))
@pytest.mark.parametrize("device", get_available_devices(), ids=id_formatter("device"))
def test_optimizer32bit(dim1, dim2, gtype, optim_name, device):
    if device == "cpu" and optim_name.startswith("paged_"):
        pytest.skip("Paged optimizers are not meaningful on CPU")

    if optim_name.startswith("paged_") and sys.platform == "win32":
        pytest.skip("Paged optimizers can have issues on Windows.")

    if gtype == torch.bfloat16 and optim_name in ["momentum", "lars", "rmsprop"]:
        pytest.skip()
    if dim1 == 1 and dim2 == 1:
        return
    p1 = torch.randn(dim1, dim2, device=device, dtype=gtype) * 0.1
    p2 = p1.clone()
    p1 = p1.float()

    torch_optimizer = str2optimizers[optim_name][0]([p1])
    bnb_optimizer = str2optimizers[optim_name][1]([p2])

    if gtype == torch.float32:
        atol, rtol = 1e-6, 1e-5
    elif gtype == torch.bfloat16:
        atol, rtol = 1e-3, 1e-2
    else:
        atol, rtol = 1e-4, 1e-3

    for i in range(k):
        g = torch.randn(dim1, dim2, device=device, dtype=gtype) * 0.01
        p1.grad = g.clone().float()
        p2.grad = g.clone()

        bnb_optimizer.step()
        torch_optimizer.step()

        for name1, name2 in str2statenames[optim_name]:
            torch.testing.assert_close(
                torch_optimizer.state[p1][name1],
                bnb_optimizer.state[p2][name2].to(device),
                atol=atol,
                rtol=rtol,
            )

        # since Lion can have pretty noisy updates where things lie at the boundary
        # allow up to 15 errors for Lion
        assert_most_approx_close(p1, p2.float(), atol=atol, rtol=rtol, max_error_count=15)

        if i % (k // 5) == 0 and i > 0:
            buf = io.BytesIO()
            torch.save(bnb_optimizer.state_dict(), buf)
            del bnb_optimizer
            bnb_optimizer = None
            bnb_optimizer = str2optimizers[optim_name][1]([p2])
            buf.seek(0)
            bnb_optimizer.load_state_dict(torch.load(buf))
            # since Lion can have pretty noisy updates where things lie at the boundary
            # allow up to 10 errors for Lion
            assert_most_approx_close(p1, p2.float(), atol=atol, rtol=rtol, max_error_count=10)
            for name1, name2 in str2statenames[optim_name]:
                # since Lion can have pretty noisy updates where things lie at the boundary
                # allow up to 10 errors for Lion
                assert_most_approx_close(
                    torch_optimizer.state[p1][name1],
                    bnb_optimizer.state[p2][name2],
                    atol=atol,
                    rtol=rtol,
                    max_error_count=10,
                )

        if gtype != torch.float32:
            # the adam buffers should also be close because they are 32-bit
            # but the parameters can diverge because they are 16-bit
            # the difference grow larger and larger with each update
            # --> copy the state to keep weights close
            p1.data = p1.data.to(p2.dtype).float()
            p2.copy_(p1.data)
            torch.testing.assert_close(p1.to(p2.dtype), p2)
        if optim_name in ["lars", "lamb"]:
            assert bnb_optimizer.state[p2]["unorm_vec"] > 0.0


@pytest.mark.parametrize("gtype", [torch.float32, torch.float16, torch.bfloat16], ids=describe_dtype)
@pytest.mark.parametrize("dim1", [1024], ids=id_formatter("dim1"))
@pytest.mark.parametrize("dim2", [32, 1024], ids=id_formatter("dim2"))
@pytest.mark.parametrize("device", get_available_devices(), ids=id_formatter("device"))
def test_lion32bit_weight_decay(dim1, dim2, gtype, device):
    """Lion must use *decoupled* weight decay (p *= 1 - lr*wd), matching the Lion paper
    and the lion_pytorch reference.

    Regression test for a coupled-vs-decoupled weight-decay bug: the shared 32-bit
    optimizer path (used by the `default` backend, i.e. MPS and any device without a
    dedicated kernel) folded weight decay into the gradient (coupled L2) for Lion, which
    corrupts the sign update. The existing test_optimizer32bit never caught it because it
    constructs optimizers with the default weight_decay=0, where the two forms coincide.
    """
    weight_decay = 0.1

    p1 = torch.randn(dim1, dim2, device=device, dtype=gtype) * 0.1
    p2 = p1.clone()
    p1 = p1.float()

    torch_optimizer = Lion([p1], weight_decay=weight_decay)
    bnb_optimizer = bnb.optim.Lion([p2], weight_decay=weight_decay)

    if gtype == torch.float32:
        atol, rtol = 1e-6, 1e-5
    elif gtype == torch.bfloat16:
        atol, rtol = 1e-3, 1e-2
    else:
        atol, rtol = 1e-4, 1e-3

    for i in range(k):
        g = torch.randn(dim1, dim2, device=device, dtype=gtype) * 0.01
        p1.grad = g.clone().float()
        p2.grad = g.clone()

        bnb_optimizer.step()
        torch_optimizer.step()

        # Lion's sign update is noisy at boundaries, so allow a few mismatches (matches
        # the tolerance policy in test_optimizer32bit). Under the coupled-decay bug this
        # diverges far beyond the error budget; under the correct decoupled decay it holds.
        assert_most_approx_close(p1, p2.float(), atol=atol, rtol=rtol, max_error_count=15)

        if gtype != torch.float32:
            # keep 16-bit params from drifting apart across steps (see test_optimizer32bit)
            p1.data = p1.data.to(p2.dtype).float()
            p2.copy_(p1.data)


@pytest.mark.parametrize("dim1", [1024], ids=id_formatter("dim1"))
@pytest.mark.parametrize("dim2", [32, 1024, 4097], ids=id_formatter("dim2"))
@pytest.mark.parametrize("gtype", [torch.float32, torch.float16], ids=describe_dtype)
@pytest.mark.parametrize("device", get_available_devices())
@pytest.mark.skipif(not get_available_devices(), reason="No device")
def test_global_config(dim1, dim2, gtype, device):
    if dim1 == 1 and dim2 == 1:
        return
    p1 = torch.randn(dim1, dim2, device="cpu", dtype=gtype) * 0.1
    p2 = torch.randn(dim1, dim2, device="cpu", dtype=gtype) * 0.1
    p3 = torch.randn(dim1, dim2, device="cpu", dtype=gtype) * 0.1
    mask = torch.rand_like(p2) < 0.1
    beta1 = 0.9
    beta2 = 0.999
    lr = 0.001
    eps = 1e-8

    bnb.optim.GlobalOptimManager.get_instance().initialize()
    bnb.optim.GlobalOptimManager.get_instance().override_config(p3, "optim_bits", 8)

    bnb.optim.GlobalOptimManager.get_instance().register_parameters([p1, p2, p3])
    p1 = p1.to(device)
    p2 = p2.to(device)
    p3 = p3.to(device)

    adam2 = bnb.optim.Adam([p1, p2, p3], lr, (beta1, beta2), eps)

    if gtype == torch.float32:
        atol, rtol = 1e-6, 1e-5
    else:
        atol, rtol = 1e-4, 1e-3

    for i in range(50):
        g1 = torch.randn(dim1, dim2, device=device, dtype=gtype) * 0.1 + 0.001
        g2 = torch.randn(dim1, dim2, device=device, dtype=gtype) * 0.1 + 0.001
        g3 = torch.randn(dim1, dim2, device=device, dtype=gtype) * 0.1 + 0.001
        p1.grad = g1
        p2.grad = g2
        p3.grad = g3

        adam2.step()

        assert adam2.state[p3]["state1"].dtype == torch.uint8
        assert adam2.state[p3]["state2"].dtype == torch.uint8


@pytest.mark.parametrize("device", get_available_devices())
@pytest.mark.skipif(not get_available_devices(), reason="No device")
def test_override_config_after_register(device):
    """Test that override_config works when called after register_parameters (issue #1269)."""

    mng = bnb.optim.GlobalOptimManager.get_instance()
    mng.initialize()

    p1 = torch.randn(64, 64, device="cpu") * 0.1
    p2 = torch.randn(64, 64, device="cpu") * 0.1

    # Register first, override second (the documented order)
    mng.register_parameters([p1, p2])
    p1 = p1.to(device)
    p2 = p2.to(device)

    # Override p2 to use 8-bit after register_parameters
    mng.override_config(p2, "optim_bits", 8)

    adam = bnb.optim.Adam([p1, p2], lr=0.001, optim_bits=32)

    # Run a step to trigger init_state
    p1.grad = torch.randn_like(p1) * 0.1
    p2.grad = torch.randn_like(p2) * 0.1
    adam.step()

    # p1 should be 32-bit, p2 should be 8-bit
    assert adam.state[p1]["state1"].dtype == torch.float32
    assert adam.state[p2]["state1"].dtype == torch.uint8


optimizer_names_8bit = [
    "adam8bit_blockwise",
    "lion8bit_blockwise",
    "momentum8bit_blockwise",
    "rmsprop8bit_blockwise",
    "ademamix8bit_blockwise",
    "ademamix8bit_blockwise_scheduled",
]


@pytest.mark.parametrize("optim_name", optimizer_names_8bit, ids=id_formatter("opt"))
@pytest.mark.parametrize("gtype", [torch.float32, torch.float16, torch.bfloat16], ids=describe_dtype)
@pytest.mark.parametrize("dim2", [32, 1024, 4097], ids=id_formatter("dim2"))
@pytest.mark.parametrize("dim1", [1024], ids=id_formatter("dim1"))
@pytest.mark.parametrize("device", get_available_devices())
def test_optimizer8bit(dim1, dim2, gtype, optim_name, device):
    torch.set_printoptions(precision=6)

    if dim1 == 1 and dim2 == 1:
        return

    p1 = torch.randn(dim1, dim2, device=device, dtype=gtype) * 0.1
    p2 = p1.clone()
    p1 = p1.float()
    blocksize = 256

    torch_optimizer = str2optimizers[optim_name][0]([p1])
    bnb_optimizer = str2optimizers[optim_name][1]([p2])

    if gtype == torch.float32:
        atol, rtol = 3e-3, 1e-3
        patol, prtol = 1e-5, 1e-3
    elif gtype == torch.bfloat16:
        atol, rtol = 3e-3, 1e-3
        patol, prtol = 1e-4, 1e-2
    else:
        atol, rtol = 3e-3, 1e-3
        patol, prtol = 1e-5, 1e-3

    errors = []
    relerrors = []

    for i in range(50):
        g = torch.randn(dim1, dim2, device=device, dtype=gtype) * 0.01
        p1.grad = g.clone().float()
        p2.grad = g.clone()

        torch_optimizer.step()
        bnb_optimizer.step()

        # since Lion can have pretty noisy updates where things lie at the boundary
        # assert_most_approx_close(p1, p2.float(), patol, prtol, max_error_count=0)

        dequant_states = []
        for name1, name2, qmap, max_val in str2statenames[optim_name]:
            ## For AdEMAMix, we need to dequantize [p2][name2][0] and [p2][name2][1]
            ## separately and then stack them. The qmap is shared, but absmax is also stacked.
            if optim_name == "ademamix8bit_blockwise" and name1 == "m1_m2":
                m1 = F.dequantize_blockwise(
                    code=bnb_optimizer.state[p2][qmap],
                    absmax=bnb_optimizer.state[p2][max_val][0],
                    A=bnb_optimizer.state[p2][name2][0],
                    blocksize=blocksize,
                )
                m2 = F.dequantize_blockwise(
                    code=bnb_optimizer.state[p2][qmap],
                    absmax=bnb_optimizer.state[p2][max_val][1],
                    A=bnb_optimizer.state[p2][name2][1],
                    blocksize=blocksize,
                )

                s1 = torch.stack((m1, m2))
            else:
                s1 = F.dequantize_blockwise(
                    code=bnb_optimizer.state[p2][qmap],
                    absmax=bnb_optimizer.state[p2][max_val],
                    A=bnb_optimizer.state[p2][name2],
                    blocksize=blocksize,
                )

            num_not_close = torch.isclose(torch_optimizer.state[p1][name1], s1, atol=atol, rtol=rtol) == 0
            assert num_not_close.sum().item() < 20
            dequant_states.append(s1.clone())

        err = torch.abs(p1 - p2)
        relerr = err / (torch.abs(p1) + 1e-9)
        if g.dtype == torch.bfloat16:
            assert err.mean() <= 0.00017
            assert relerr.mean() <= 0.0016
        else:
            assert err.mean() < 0.00006
            # Lion on CPU fp16 has slightly higher relative error due to sign-based updates at boundary
            relerr_the = (
                0.00062
                if (device == "cpu" and optim_name == "lion8bit_blockwise" and gtype == torch.float16)
                else 0.0006
            )
            assert relerr.mean() < relerr_the

        errors.append(err.mean().item())
        relerrors.append(relerr.mean().item())

        if i % 10 == 0 and i > 0:
            for (name1, name2, qmap, max_val), s in zip(str2statenames[optim_name], dequant_states):
                s1cpy = s.clone()
                raws1cpy = bnb_optimizer.state[p2][name2].clone()
                qmap1 = bnb_optimizer.state[p2][qmap].clone()

                buf = io.BytesIO()
                torch.save(bnb_optimizer.state_dict(), buf)
                del bnb_optimizer
                bnb_optimizer = None
                bnb_optimizer = str2optimizers[optim_name][1]([p2])
                buf.seek(0)
                bnb_optimizer.load_state_dict(torch.load(buf))
                torch.testing.assert_close(raws1cpy, bnb_optimizer.state[p2][name2])
                torch.testing.assert_close(qmap1, bnb_optimizer.state[p2][qmap])

                ## For AdEMAMix, we need to dequantize [p2][name2][0] and [p2][name2][1]
                ## separately and then stack them. The qmap is shared, but absmax is also stacked.
                if optim_name == "ademamix8bit_blockwise" and name1 == "m1_m2":
                    s1 = torch.stack(
                        (
                            F.dequantize_blockwise(
                                code=bnb_optimizer.state[p2][qmap],
                                absmax=bnb_optimizer.state[p2][max_val][0],
                                A=bnb_optimizer.state[p2][name2][0],
                                blocksize=blocksize,
                            ),
                            F.dequantize_blockwise(
                                code=bnb_optimizer.state[p2][qmap],
                                absmax=bnb_optimizer.state[p2][max_val][1],
                                A=bnb_optimizer.state[p2][name2][1],
                                blocksize=blocksize,
                            ),
                        )
                    )
                else:
                    s1 = F.dequantize_blockwise(
                        code=bnb_optimizer.state[p2][qmap],
                        absmax=bnb_optimizer.state[p2][max_val],
                        A=bnb_optimizer.state[p2][name2],
                        blocksize=blocksize,
                    )

                torch.testing.assert_close(s1cpy, s1)

                num_not_close = torch.isclose(torch_optimizer.state[p1][name1], s1, atol=atol, rtol=rtol) == 0
                assert num_not_close.sum().item() < 20

            # Lion can have pretty noisy updates where things lie at the boundary
            assert_most_approx_close(p1, p2.float(), patol, prtol, max_error_count=0)

        # the parameters diverge quickly. Here we keep them close
        # together so we can test against the Adam error
        p1.data = p1.data.to(gtype).float()
        p2.copy_(p1.data)
        torch.testing.assert_close(p1.to(gtype), p2)
        for (name1, name2, qmap, max_val), s in zip(str2statenames[optim_name], dequant_states):
            torch_optimizer.state[p1][name1].copy_(s.data)


optimizer_names_benchmark = [
    "adam8bit_blockwise",
    "paged_adam8bit_blockwise",
    "ademamix8bit_blockwise",
    "paged_ademamix8bit_blockwise",
    "ademamix8bit_blockwise_scheduled",
    "paged_ademamix8bit_blockwise_scheduled",
    "lion8bit_blockwise",
    "paged_lion8bit_blockwise",
    "paged_ademamix8bit_blockwise",
]


@pytest.mark.parametrize("dim1", [4096], ids=id_formatter("dim1"))
@pytest.mark.parametrize("dim2", [4096], ids=id_formatter("dim2"))
@pytest.mark.parametrize("gtype", [torch.float32, torch.bfloat16, torch.float16], ids=describe_dtype)
@pytest.mark.parametrize("optim_name", optimizer_names_benchmark, ids=id_formatter("opt"))
@pytest.mark.benchmark
def test_benchmark_blockwise(dim1, dim2, gtype, optim_name, device):
    if dim1 == 1 and dim2 == 1:
        return
    p1 = torch.randn(dim1, dim2, device=device, dtype=gtype) * 0.1

    bnb_optimizer = str2optimizers[optim_name][1]([p1])

    g = torch.randn(dim1, dim2, device=device, dtype=gtype) * 0.01
    p1.grad = g
    total_steps = 500
    for i in range(total_steps):
        if i == total_steps // 5:
            # 100 iterations for burn-in
            sync_gpu(p1)
            t0 = time.time()

        bnb_optimizer.step()

    sync_gpu(p1)
    s = time.time() - t0
    print("")
    params = (total_steps - total_steps // 5) * dim1 * dim2
    print(optim_name, gtype, s, params, s / params)
    # assert s < 3.9


ademamix_state_dict_opts = [
    ("AdEMAMix8bit", lambda p: bnb.optim.AdEMAMix8bit(p, lr=1e-3)),
    ("AdEMAMix32bit", lambda p: bnb.optim.AdEMAMix(p, lr=1e-3)),
    ("AdEMAMix8bit_scheduled", lambda p: bnb.optim.AdEMAMix8bit(p, lr=1e-3, t_alpha=100, t_beta3=100)),
    ("AdEMAMix32bit_scheduled", lambda p: bnb.optim.AdEMAMix(p, lr=1e-3, t_alpha=100, t_beta3=100)),
]


@pytest.mark.parametrize(
    "optim_name,optim_factory",
    ademamix_state_dict_opts,
    ids=[x[0] for x in ademamix_state_dict_opts],
)
@pytest.mark.parametrize("device", get_available_devices())
@pytest.mark.skipif(not get_available_devices(), reason="No device")
def test_ademamix_state_dict_no_nan(optim_name, optim_factory, device):
    """Test that AdEMAMix can save/load state_dict and continue training without NaN.

    Regression test for https://github.com/bitsandbytes-foundation/bitsandbytes/issues/1382
    """

    import torch.nn as nn

    torch.manual_seed(42)
    model = nn.Linear(256, 64).to(device)
    opt = optim_factory(model.parameters())

    # Train a few steps to populate optimizer state
    for _ in range(10):
        x = torch.randn(8, 256, device=device)
        loss = model(x).sum()
        loss.backward()
        opt.step()
        opt.zero_grad()

    # Save state
    model_sd = {k: v.clone() for k, v in model.state_dict().items()}
    opt_sd = opt.state_dict()
    opt_buf = io.BytesIO()
    model_buf = io.BytesIO()
    torch.save(opt_sd, opt_buf)
    torch.save(model_sd, model_buf)

    # Create fresh model and optimizer, load state
    model2 = nn.Linear(256, 64).to(device)
    model_buf.seek(0)
    model2.load_state_dict(torch.load(model_buf))
    opt2 = optim_factory(model2.parameters())
    opt_buf.seek(0)
    opt2.load_state_dict(torch.load(opt_buf))

    # Verify loaded state matches original byte-for-byte
    orig_params = list(model.parameters())
    loaded_params = list(model2.parameters())
    for p_idx in range(len(orig_params)):
        s1 = opt.state[orig_params[p_idx]]
        s2 = opt2.state[loaded_params[p_idx]]
        for k in s1:
            if isinstance(s1[k], torch.Tensor):
                assert s1[k].shape == s2[k].shape, f"Shape mismatch for param {p_idx} {k}"
                assert s1[k].dtype == s2[k].dtype, f"Dtype mismatch for param {p_idx} {k}"
                torch.testing.assert_close(s1[k], s2[k])

    # Resume training and verify no NaN
    for i in range(10):
        x = torch.randn(8, 256, device=device)
        loss = model2(x).sum()
        assert not torch.isnan(loss), f"NaN loss at step {i} after loading state_dict"
        assert not torch.isinf(loss), f"Inf loss at step {i} after loading state_dict"
        loss.backward()
        opt2.step()
        opt2.zero_grad()

        # Check parameters for NaN/Inf after each step
        for p in model2.parameters():
            assert not p.isnan().any(), f"NaN in parameters at step {i} after loading state_dict"
            assert not p.isinf().any(), f"Inf in parameters at step {i} after loading state_dict"

    # Verify the original and loaded optimizers produce identical updates
    # from the same starting point (immediately after loading, before any divergence)
    torch.manual_seed(999)
    x_orig = torch.randn(8, 256, device=device)
    x_loaded = x_orig.clone()

    # Reset models to the saved checkpoint weights
    model.load_state_dict(model_sd)
    model2.load_state_dict(model_sd)

    # Reload optimizer states from the same checkpoint into two fresh optimizers
    opt_fresh = optim_factory(model.parameters())
    opt_fresh.load_state_dict(opt_sd)
    opt_fresh2 = optim_factory(model2.parameters())
    opt_fresh2.load_state_dict(opt_sd)

    loss_a = model(x_orig).sum()
    loss_a.backward()
    opt_fresh.step()
    opt_fresh.zero_grad()

    loss_b = model2(x_loaded).sum()
    loss_b.backward()
    opt_fresh2.step()
    opt_fresh2.zero_grad()

    for p_a, p_b in zip(model.parameters(), model2.parameters()):
        torch.testing.assert_close(p_a, p_b)


@pytest.mark.parametrize("optim_cls", [bnb.optim.LAMB, bnb.optim.LAMB32bit], ids=id_formatter("opt"))
@pytest.mark.parametrize("max_unorm", [0.0, 0.5, 2.0], ids=id_formatter("max_unorm"))
def test_lamb_max_unorm_threaded_to_config(optim_cls, max_unorm):
    # The LAMB constructors accepted a `max_unorm` argument but passed a hardcoded 1.0
    # to the base optimizer, so the user value never reached the optimizer config.
    # (LAMB8bit rejects non-default values instead, since the 8-bit blockwise kernel
    # does not apply update-norm clipping; see test_lamb8bit_rejects_non_default_max_unorm.)
    p = [torch.nn.Parameter(torch.randn(8, 8))]
    opt = optim_cls(p, max_unorm=max_unorm)
    assert opt.args.max_unorm == max_unorm


def test_lamb_max_unorm_changes_update():
    # Behavioral regression: on the 32-bit LAMB path, `max_unorm` drives trust-ratio
    # clipping of the update. Before the fix the argument was ignored (always 1.0), so a
    # tight and a loose value produced identical updates. Runs on CPU, which implements
    # the 32-bit LAMB kernel.
    def one_step(max_unorm):
        torch.manual_seed(0)
        p = torch.nn.Parameter(torch.randn(128, 128))
        opt = bnb.optim.LAMB([p], lr=1e-1, max_unorm=max_unorm)
        p.grad = torch.randn(128, 128) * 5.0
        opt.step()
        return p.detach().clone()

    tight = one_step(1e-4)  # aggressive clipping
    loose = one_step(10.0)  # effectively no clipping
    assert not torch.allclose(tight, loose)


def test_lamb8bit_rejects_amsgrad():
    # amsgrad is unused by the base optimizer; mirror the Adam8bit/AdamW8bit guard (relates to #1261).
    p = [torch.nn.Parameter(torch.randn(8, 8))]
    with pytest.raises(ValueError):
        bnb.optim.LAMB8bit(p, amsgrad=True)
    # default (amsgrad=False) still constructs
    bnb.optim.LAMB8bit(p)


def test_lamb8bit_rejects_non_default_max_unorm():
    # The 8-bit blockwise update does not implement update-norm clipping, so a
    # non-default max_unorm would be silently ignored; reject it instead.
    p = [torch.nn.Parameter(torch.randn(8, 8))]
    with pytest.raises(ValueError):
        bnb.optim.LAMB8bit(p, max_unorm=0.5)
    with pytest.raises(ValueError):
        bnb.optim.LAMB8bit(p, max_unorm=0.0)
    # default (max_unorm=1.0) still constructs
    bnb.optim.LAMB8bit(p, max_unorm=1.0)


def test_adagrad8bit_rejects_non_8_optim_bits():
    # optim_bits is ignored (Adagrad8bit always uses 8-bit); guard invalid values (relates to #1261).
    p = [torch.nn.Parameter(torch.randn(8, 8))]
    with pytest.raises(ValueError):
        bnb.optim.Adagrad8bit(p, optim_bits=32)
    # default (optim_bits=8) still constructs
    bnb.optim.Adagrad8bit(p)
